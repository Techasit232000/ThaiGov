import os
from dotenv import load_dotenv
load_dotenv()
GOOGLE_SHEET_ID=os.getenv('GOOGLE_SHEET_ID')
ALPHAVANTAGE_API_KEY=os.getenv('ALPHAVANTAGE_API_KEY')
