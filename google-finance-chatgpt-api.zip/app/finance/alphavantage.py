def get_stock_price(symbol:str): return {'symbol':symbol,'price':'api'}
